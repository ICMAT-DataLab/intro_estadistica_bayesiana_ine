//  Modelo para ilustrar Stan
data {
int<lower=0> J; // numero de colegios, entero no negativo 
real y[J]; // efectos estimados de los tratamientos, reales
real<lower=0> sigma[J]; // errores estnadar de los estimadores de los efectos, reales no negativos 
}
parameters {
real mu; // media de la población 
real<lower=0> tau; // desviación típica de la población.reales no negativos
vector[J] eta; // errores en el nivel de colegio 
}
transformed parameters {
vector[J] theta; // efectos del colegio 
theta = mu + tau*eta;
}
model {
eta ~ normal(0, 1);
y ~ normal(theta, sigma);
}
