// Modelo binomial con a priori beta(1,1) 
data {
  int<lower=0> N;              // no. experimentos 
  int<lower=0> y;              // no. exitos 
}
parameters {
  real<lower=0,upper=1> theta; // probabilidad de exito (rango (0,1))
}
model {
  // modelo 
  theta ~ beta(1, 20);          // prior
  y ~ binomial(N, theta);      // verosimilitud 
  }
 

