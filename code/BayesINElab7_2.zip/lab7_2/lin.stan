// Modelo lineal Gaussiano con priors ajustables 
data {
  int<lower=0> N; // numero de datos
  vector[N] x;    // covariable 
  vector[N] y;    // target
  real xpred;     // nueva covariable para hacer predicciones
  real pmualpha;  // media a priori para 
  real psalpha;   // dt a priori para alpha
  real pmubeta;   // media a priori para beta
  real psbeta;    // dt a priori para beta
  real pssigma;   // dt a priori para half-normal prior de sigma
}
parameters {
  real alpha;          // intercept
  real beta;           // pendiente 
  real<lower=0> sigma; // dt debe ser no negativa 
}
transformed parameters {
    vector[N] mu = alpha + beta*x;      // modelo lineal 
}
model {
  alpha ~ normal(pmualpha, psalpha);  // prior
  beta ~ normal(pmubeta, psbeta);     // prior
  sigma ~ normal(0, pssigma);         // como sigma ha de ser no negativa 
                                      // esta es la prior mitad-normal 
  y ~ normal(mu, sigma);              // versoimilitud 
  }
generated quantities {
  // muestra de la predictiva 
  real ypred = normal_rng(alpha + beta*xpred, sigma);
  // calcula log densidades predictivas 
  vector[N] log_lik;
  for (i in 1:N)
    log_lik[i] = normal_lpdf(y[i] | mu[i], sigma);
}

   

