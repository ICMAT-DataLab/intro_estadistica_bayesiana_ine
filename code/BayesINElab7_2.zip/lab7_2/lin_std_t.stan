// Modelo lineal con ruidos t 
data {
  int<lower=0> N; // no  datos
  vector[N] x;    // predictor
  vector[N] y;    // target
  real xpred;     // nuevo predictor para hacer prediccioness
}
transformed data {
  // transfos deterministicas de datos 
  vector[N] x_std = (x - mean(x)) / sd(x);
  vector[N] y_std = (y - mean(y)) / sd(y);
  real xpred_std  = (xpred - mean(x)) / sd(x);
}
parameters {
  real alpha;          // intercept
  real beta;           // pendiente 
  real<lower=0> sigma_std; // dt restringida a ser positiva 
  real<lower=1> nu;    // grados libertad restringidos a >1
}
transformed parameters {
  // transfos det de parametro y datos 
  vector[N] mu_std = alpha + beta*x_std; // modelo lineal
}
model {
  alpha ~ normal(0, 1); // prior deb informativa (dados los datos tip)
  beta ~ normal(0, 1);  // prior deb informativa (dados datos tip)
  sigma_std ~ normal(0, 1); // id 
  nu ~ gamma(2, 0.1);   // seleccion habitual ver Juárez and Steel(2010)
  y_std ~ student_t(nu, mu_std, sigma_std); // verosimilitud 
}
generated quantities {
  // transformar a escala original de datos 
  vector[N] mu = mu_std*sd(y) + mean(y);
  real<lower=0> sigma = sigma_std*sd(y);
  // muestreo predictiva 
  real ypred = student_t_rng(nu, (alpha + beta*xpred_std)*sd(y)+mean(y), sigma*sd(y));
  }


