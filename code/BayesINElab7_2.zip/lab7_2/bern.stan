// Modelo de Bernoulli 
data {
  int<lower=0> N;              // numero de observaciones 
  int<lower=0,upper=1> y[N];   // vector de observaciones binarias 
}
parameters {
  real<lower=0,upper=1> theta; // probabilidad de exito 
}
model {
    theta ~ beta(1, 1);          // a priori  
  y ~ bernoulli(theta);        // modelo de observaciones/ verosimilitud 
    }


